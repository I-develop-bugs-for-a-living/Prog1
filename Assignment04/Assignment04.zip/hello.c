#include <stdio.h>

int main(void) {
    printf("Hello Word");
    return 0;
};