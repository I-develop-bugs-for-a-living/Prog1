
#include <stdio.h>

int main() {

    char s[] = "Hel🍔o";
    printf("%s", s);

    return 0;
    
}